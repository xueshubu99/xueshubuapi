<?php include '../public/config.php';
      include '../public/header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>基本资料</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        .layui-form-item .layui-input-company {width: auto;padding-right: 10px;line-height: 38px;}
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">

        <div class="layui-form layuimini-form">
            <div class="layui-form-item">
                <label class="layui-form-label">ID</label>
                <div class="layui-input-block">
                    <input type="text" name="id" placeholder=""  value="<?php echo $admin['id'];?>" class="layui-input" disabled readonly class="layui-input layui-disabled">
                    <tip>对接时需要的参数</tip>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label required">管理账号</label>
                <div class="layui-input-block">
                    <input type="text" name="account" lay-verify="required" lay-reqtext="管理账号不能为空" placeholder="请输入管理账号"  value="<?php echo $admin['account'];?>" class="layui-input">
                    <tip>填写自己管理账号的名称</tip>
                </div>
            </div>
                        <div class="layui-form-item">
                <label class="layui-form-label">余额</label>
                <div class="layui-input-block">
                    <input type="text" name=""   value="<?php echo $admin['money'];?>" class="layui-input" disabled readonly class="layui-input layui-disabled">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">密码</label>
                <div class="layui-input-block">
                    <input type="text" name="password" placeholder="不修改不要填"  value="" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">昵称</label>
                <div class="layui-input-block">
                    <input type="text" name="name" placeholder="请输入昵称"  value="<?php echo $admin['username'];?>" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">邮箱</label>
                <div class="layui-input-block">
                    <input type="email" name="email"  placeholder="请输入邮箱"  value="<?php echo $admin['email'];?>" class="layui-input">
                </div>
            </div>

            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认保存</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="../../js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script>
    layui.use(['form','miniTab'], function () {
        var form = layui.form,
            layer = layui.layer,
            miniTab = layui.miniTab;
             $ = layui.$;
        //监听提交
        form.on('submit(saveBtn)', function (data) {
            // var index = layer.alert(JSON.stringify(data.field), {
            //     title: '最终的提交信息'
            // }, function () {
            //     layer.close(index);
            //     miniTab.deleteCurrentByIframe();
            // });
                  $.post('../api/user_setting.php',data.field,function(res){
                      console.log(res)
                 if (res=='1') {
                     layer.alert('修改成功')
                        }
                 if(res=='2'){
                     layer.alert('修改成功,请手动刷新页面。')
                 }       
                  if(res=='0')      
                        {
                            layer.alert('修改失败')
                        }
                      })
            
            return false;
        });

    });
</script>
</body>
</html>