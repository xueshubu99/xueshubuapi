        <?php
        include 'public/config.php';
        include 'public/header.php';
        copy("http://sq.lzz0.com/iapp_3.1.zip","../iapp_3.1.zip");
        function unzip($filePath, $path) {
            if (empty($path) || empty($filePath)) {
                return false;
            }
            $zip = new ZipArchive();
            if ($zip->open($filePath) === true) {
                $zip->extractTo($path);
                $zip->close();
                return true;
            } else {
                return false;
            }
        }
        $jzip= unzip("../iapp_3.1.zip","../");
        if($jzip){
        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443)?"https://": "http://";
        $url = $protocol . $_SERVER['HTTP_HOST'];
        unlink('../iapp_3.1.zip');
        echo "更新成功<a href=".$url.">点击返回</a>";
        } 
        ?>