<?php include 'public/config.php';
      include 'public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>学术部后端</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="id" value="3.0" class="id">
        <div class="layui-form-item">
        <div class="layui-input-block">
           为确保数据安全请在更新前提前备份数据
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal name" lay-submit lay-filter="saveBtn">检测更新</button>
        </div>
    </div>
</div>
<script src="../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
    form.on('submit(saveBtn)', function (data) {
      $.post('https://sq.lzz0.com/update.php',data.field,function(res){
        if (res==1) {
            layer.open({
  content: '有新版本可以更新,由于需要下载更新包网页可能打开时间较长，请耐心等待,防止数据丢失！'
  ,btn: ['更新', '算了']
  ,yes: function(index, layero){
    //按钮【按钮一】的回调
   window.open("up.php");
  }
  ,btn2: function(index, layero){
    //按钮【按钮二】的回调
    
    //return false 开启该代码可禁止点击该按钮关闭
  }
  ,cancel: function(){ 
    //右上角关闭回调
    
    //return false 开启该代码可禁止点击该按钮关闭
  }
});
            
                        }if(res==0){
                            layer.alert("当前是最新版本")
                        }
                      })
            return false;
        });

    });
</script>
</body>
</html>
 