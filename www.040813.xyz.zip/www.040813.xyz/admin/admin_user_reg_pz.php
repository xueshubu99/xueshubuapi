<?php include 'public/config.php';
      include 'public/header.php';
?>
<?php
if($admin['id']==$chaoji){
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>基本配置</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        .layui-form-item .layui-input-company {width: auto;padding-right: 10px;line-height: 38px;}
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">

        <div class="layui-form layuimini-form">
           <div class="layui-form-item">
                <label class="layui-form-label required">软件价格</label>
                <div class="layui-input-block">
                    <input type="number" name="app_pay" lay-verify="required" lay-reqtext="软件价格不能为空" placeholder="请输入添加一个软件的价格"  value="<?php echo $admin_pz['app_pay'];?>" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label required">注册赠送余额</label>
                <div class="layui-input-block">
                    <input type="number" name="money_reg" lay-verify="required" lay-reqtext="注册赠送余额不能为空" placeholder="请输入注册赠送余额"  value="<?php echo $admin_pz['money_reg'];?>" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认保存</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="../../js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script>
    layui.use(['form','miniTab'], function () {
        var form = layui.form,
            layer = layui.layer,
            miniTab = layui.miniTab;
             $ = layui.$;
        //监听提交
        form.on('submit(saveBtn)', function (data) {
                  $.post('api/admin_pz.php',data.field,function(res){
                      console.log(res)
                 if (res=='1') {
                     layer.alert('修改成功')
                        }else{
                     layer.alert('修改失败')
                        }
                      })
            
            return false;
        });

    });
</script>
</body>
</html>    
<?php
}else{
    echo '<h1>没有权限</h1>';
}
?>
