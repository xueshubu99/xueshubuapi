<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO admin_notice(title,content,date)VALUES('{$_POST['title']}','{$_POST['content']}','{$date}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>