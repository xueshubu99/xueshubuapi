<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
 $ids=$_POST['id'];
 $stmt = $pdo->prepare("DELETE FROM admin WHERE id in($ids)"); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>