<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO bbs_sort(admin_id,app_name,sort_name,app_id)VALUES('{$admin['id']}','{$_POST['app_name']}','{$_POST['sort_name']}','{$app_id}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>