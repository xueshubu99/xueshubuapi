<?php include '../public/config.php';
      include '../public/header_app.php';
?>
<?php
    $sql = "SELECT * FROM app where app_name='{$_POST['app_name']}'"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
        echo 3;
        exit;
    }
//判断是否为超级管理员
    if($admin['id']==$chaoji){
$sql = "INSERT INTO `user` (account,password,username,experience,money,signature,date_reg,date_last,vip_if,vip_start,vip_end,email,admin_id,app_name) VALUES('{$admin['account']}','{$admin['password']}','{$admin['username']}','99999','99999','该用户很懒什么也没写','{$date}','{$date}','是','{$date}','{2099-01-12 07:14:40}','{$admin['email']}','{$admin['id']}','{$_POST['app_name']}')";
    $stmt = $pdo->prepare($sql); 
    $stmt ->execute();
    $sql = "INSERT INTO `app`(app_name,admin_id)VALUES('{$_POST['app_name']}','{$admin['id']}')";
    }else{
    $sql = "select * from `admin` where id = '{$admin['id']}'";
    $stmt = $pdo->prepare($sql); 
    $stmt ->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $money = $find[0]['money'];
    if($money<$admin_pz['app_money']){
    //余额不够
     echo 2; 
     exit;
    }else{
    $sql = "update `admin` set money=('{$money}'-'{$admin_pz['app_money']}') where id = '{$admin['id']}';INSERT INTO `user` (account,password,username,experience,money,signature,date_reg,date_last,vip_if,vip_start,vip_end,email,admin_id,app_name) VALUES('{$admin['account']}','{$admin['password']}','{$admin['username']}','99999','99999','该用户很懒什么也没写','{$date}','{$date}','是','{$date}','{2099-01-12 07:14:40}','{$admin['email']}','{$admin['id']}','{$_POST['app_name']}')";
    }
    }
//创建软件
    $stmt = $pdo->prepare($sql); 
    if($stmt->execute()){
    	echo 1;
    }else{
    	echo 0;
    }
?>