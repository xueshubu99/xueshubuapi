<?php include '../public/config.php';
      include '../public/header_app.php';
?>
<?php
$sql = "update app set app_name='{$_POST['app_name']}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>