<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO admin(account,password,username,email,money,date_reg,date_last)VALUES('{$_POST['account']}','{$_POST['password']}','{$_POST['username']}','{$_POST['email']}','{$_POST['money']}','{$date}','{$date}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>