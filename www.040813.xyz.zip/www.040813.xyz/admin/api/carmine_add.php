<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
if(!empty($_POST['number']) and $_POST['number']>1){
//随机数生成
function getRandomString($len, $chars=null)
{
    if (is_null($chars)){
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
}
    mt_srand(10000000*(double)microtime());
    for ($i = 0, $str = '', $lc = strlen($chars)-1; $i < $len; $i++){
        $str .= $chars[mt_rand(0, $lc)]; 
    }
    return $str;
}   
   try {
for($i=0;$i<$_POST['number'];$i++){
   $con = getRandomString(10);
   $sql = "INSERT INTO carmine(content,admin_id,app_name,state,app_id)VALUES('{$con}','{$admin['id']}','{$_POST['app_name']}','未使用','{$app_id}')"; 
   $stmt = $pdo->prepare($sql); 
   $stmt->execute();
}
 echo 1;
 }catch (Exception $e) {
        echo 0;
    }
   

}else{
    $sql = "INSERT INTO carmine(content,admin_id,app_name,state)VALUES('{$_POST['content']}','{$admin['id']}','{$_POST['app_name']}','未使用','{$app_id}')";
    $stmt = $pdo->prepare($sql); 
   if($stmt->execute()){
	 echo 1;
     }else{
	 echo 0;
     }
}


?>