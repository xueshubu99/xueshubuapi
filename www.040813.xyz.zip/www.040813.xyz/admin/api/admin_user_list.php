<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
if(!empty($_GET['account'])){
    $sql = "select * from admin where account='{$_GET['account']}' ORDER BY id DESC";    
}else{
    $sql = "select * from admin where id !='647551725' ORDER BY id DESC";  
}
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo '{"code": 0,"msg": "","count":'.count($find).',"data":';
    echo json_encode($find);
    echo "}";
?>