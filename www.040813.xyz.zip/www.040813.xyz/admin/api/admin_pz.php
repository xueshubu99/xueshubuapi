<?php include '../public/config.php';
      include '../public/header.php';
     $sql = "update `admin_pz` set app_pay='{$_POST['app_pay']}',money_reg='{$_POST['money_reg']}' where id = '{$admin['id']}'";
    $stmt = $pdo-> prepare($sql);
    if($stmt ->execute()){
        echo 1;
    }else{
        echo 0;
    }

?>