<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO `bbs_post`(title,content,img,sort,state,user_id,user_name,user_account,date_publish,date_update,admin_id,app_name,app_id,number_reading,number_good)VALUES('{$_POST['title']}','{$_POST['content']}','{$_POST['img']}','{$_POST['sort']}','{$_POST['state']}','{$_POST['user_id']}','{$_POST['user_name']}','{$_POST['user_account']}','{$_POST['date_publish']}','{$_POST['date_update']}','{$admin['id']}','{$_POST['app_name']}','{$app_id}','{$_POST['number_reading']}','{$_POST['number_good']}')";
    $stmt = $pdo->prepare($sql); 
    if($stmt->execute()){
    	echo 1;
    }else{
    	echo 0;
    }
?>