<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "INSERT INTO `user`(username,account,password,date_reg,date_last,vip_if,email,app_name,money,experience,signature,vip_start,vip_end,admin_id,app_id,state)VALUES('{$_POST['username']}','{$_POST['account']}','{$_POST['password']}','{$_POST['date']}','{$_POST['date']}','{$_POST['vip_if']}','{$_POST['email']}','{$_POST['app_name']}','{$_POST['money']}','{$_POST['experience']}','{$_POST['signature']}','{$_POST['vip_start']}','{$_POST['vip_end']}','{$admin['id']}','{$app_id}','{$_POST['state']}')";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>