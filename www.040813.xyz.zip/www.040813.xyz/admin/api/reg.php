<?php include '../public/config.php';
?>
<?php
session_start();

$code = trim($_POST['code']);

if($code!=$_SESSION["helloweba_num"]){

  echo '3';
  exit;

}
    $sql = "select * from admin_pz where id = '1'";
    $stmt = $pdo->prepare($sql);
    $stmt ->execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
    $admin_pz = $find[0];    
    }
      
    $sql = "SELECT * FROM admin where account='{$_POST['account']}'"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
      echo '0';
      exit;
    }
    
    $date = date("Y-m-d H:i:s");
    $sql = "insert into `admin` (account,password,date_reg,date_last,money,email,username)VALUES('{$_POST['account']}','{$_POST['password']}','{$date}','{$date}','{$admin_pz['money_reg']}','{$_POST['email']}','{$_POST['username']}')"; 
    $stmt = $pdo->prepare($sql);
    if($stmt->execute()){
    
    $sql = "SELECT * FROM admin where account='{$_POST['account']}'"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC); 
    setcookie('admin',$find[0]['account'],time()+3600,'/');
    setcookie('id',$find[0]['id'],time()+3600,'/');
    setcookie('cCode',md5($find[0]['account'].'676qruyghb0--O'),time()+3600,'/');
    echo '1';
    return false;
      exit;
    }
?>
