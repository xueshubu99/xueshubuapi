<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "SELECT * FROM bbs_sort where sort_name='{$_POST['sort']}' and admin_id='{$admin['id']}' and app_name='{$_POST['app_name']}'";
      $stmt = $pdo->prepare($sql);
      $stmt->execute();
      $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      echo 2;
      exit;
      }
$sql = "update bbs_post set app_name='{$_POST['app_name']}',title='{$_POST['title']}',content='{$_POST['content']}',img='{$_POST['img']}',sort='{$_POST['sort']}',state='{$_POST['state']}',user_id='{$_POST['user_id']}',date_publish='{$_POST['date_publish']}',date_update='{$_POST['date_update']}',user_account='{$_POST['user_account']}',user_name='{$_POST['user_name']}',number_reading='{$_POST['number_reading']}',number_good='{$_POST['number_good']}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>