<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php

	$sql = "select * from yzf where adminid = '100'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $sql = "update yzf set id='{$_POST['id']}',ym='{$_POST['ym']}',my='{$_POST['my']}' where adminid = '{$admin['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>