<?php include '../public/config.php';
?>
<?php

session_start();

$code = trim($_POST['code']);

if($code!=$_SESSION["helloweba_num"]){

  echo '3';
  exit;

}

    $account = $_POST['account'];
    $sql = "SELECT * FROM admin where account='{$account}'"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
      echo '0';
      exit;
    }
   $admin = $find[0];
    if($admin['password'] != $_POST['password']){
      echo '2';
      exit;
    }
    setcookie('admin',$admin['account'],time()+360000,'/');
    setcookie('id',$admin['id'],time()+360000,'/');
    setcookie('cCode',md5($admin['account'].'676qruyghb0--O'),time()+360000,'/');
    echo '1';
    return false;
?>
