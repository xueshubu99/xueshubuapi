<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
if(empty($_POST['password'])){
   $sql = "update `user` set account='{$_POST['account']}',username='{$_POST['username']}',app_name='{$_POST['app_name']}',email='{$_POST['email']}',date_reg='{$_POST['date_reg']}',vip_if='{$_POST['vip_if']}',vip_start='{$_POST['vip_start']}',vip_end='{$_POST['vip_end']}',money='{$_POST['money']}',signature='{$_POST['signature']}',experience='{$_POST['experience']}',app_id='{$app_id}',state='{$_POST['state']}' where id = '{$_POST['id']}'"; 
}else{
 $sql = "update `user` set account='{$_POST['account']}',password='{$_POST['password']}',username='{$_POST['username']}',app_name='{$_POST['app_name']}',email='{$_POST['email']}',date_reg='{$_POST['date_reg']}',vip_if='{$_POST['vip_if']}',vip_start='{$_POST['vip_start']}',vip_end='{$_POST['vip_end']}',money='{$_POST['money']}',signature='{$_POST['signature']}',experience='{$_POST['experience']}',app_id='{$app_id}',state='{$_POST['state']}' where id = '{$_POST['id']}'";
}
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>