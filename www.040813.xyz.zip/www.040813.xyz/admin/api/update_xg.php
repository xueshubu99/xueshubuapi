<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "update `update` set app_name='{$_POST['app_name']}',title='{$_POST['title']}',content='{$_POST['content']}',download_url='{$_POST['download_url']}',update_if='{$_POST['update_if']}',version='{$_POST['version']}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);

if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>