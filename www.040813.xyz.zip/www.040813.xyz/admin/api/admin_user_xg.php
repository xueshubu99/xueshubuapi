<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
if(!empty($_POST['password'])){
 $psd=$_POST['password'];   
 $sql = "update admin set account='{$_POST['account']}',password='{$psd}',name='{$_POST['name']}',email='{$_POST['email']}',money='{$_POST['money']}' where id = '{$_POST['id']}'";
}else{
    $sql = "update admin set account='{$_POST['account']}',name='{$_POST['name']}',email='{$_POST['email']}',money='{$_POST['money']}' where id = '{$_POST['id']}'";
}

$stmt = $pdo->prepare($sql);

if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>