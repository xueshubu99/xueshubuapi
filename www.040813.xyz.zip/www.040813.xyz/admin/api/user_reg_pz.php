<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "update user_reg_pz set reg_vip_time='{$_POST['reg_vip_time']}',reg_money='{$_POST['reg_money']}',reg_experience='{$_POST['reg_experience']}' where admin_id='{$admin['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>