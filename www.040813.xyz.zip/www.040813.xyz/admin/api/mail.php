<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
	$sql = "select * from `mail` where admin_id = '{$admin['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $sql = "update `mail` set username='{$_POST['username']}',password='{$_POST['password']}',port='{$_POST['port']}',smtp='{$_POST['smtp']}' where admin_id = '{$admin['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>