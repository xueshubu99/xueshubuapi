<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "update goods set app_name='{$_POST['app_name']}',title='{$_POST['title']}',content='{$_POST['content']}',money='{$_POST['money']}',number='{$_POST['number']}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>