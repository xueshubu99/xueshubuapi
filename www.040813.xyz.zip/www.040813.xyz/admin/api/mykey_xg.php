<?php include '../public/config.php';
    //   include '../public/header.php';
     $sql = "update mykey set mykey='{$_POST['mykey']}' where id = '{$_POST['id']}'";
    $stmt = $pdo-> prepare($sql);
    if($stmt ->execute()){
        echo 1;
    }else{
        echo 0;
    }

?>