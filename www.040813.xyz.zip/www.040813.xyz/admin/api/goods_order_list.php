<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php 
//判断是否有搜索
if(!empty($_GET['app_name'])){
    $sql = "SELECT * FROM goods_order where admin_id='{$admin['id']}' and app_name='{$_GET['app_name']}' ORDER BY id DESC"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo '{"code": 0,"msg": "","count":'.count($find).',"data":';
    echo json_encode($find);
    echo "}";
}else {
    $sql = "SELECT * FROM goods_order where admin_id='{$admin['id']}'ORDER BY id DESC"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo '{"code": 0,"msg": "","count":'.count($find).',"data":';
    echo json_encode($find);
    echo "}";
}
?>