<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "update note set app_name='{$_POST['app_name']}',title='{$_POST['title']}',content='{$_POST['content']}',date='{$_POST['date']}',user_account='{$_POST['user_account']}',user_id='{$_POST['user_id']}',user_name='{$_POST['user_name']}',app_id='{$app_id}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);

if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>