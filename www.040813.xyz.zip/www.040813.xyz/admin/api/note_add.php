<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "SELECT * FROM user where account='{$_POST['user_account']}' and app_name='{$_POST['app_name']}' ORDER BY id DESC"; 
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find=$stmt->fetchall();
    if(empty($find)){
        echo 2;
        exit;
    }else{
    $user_id=$find[0]['id'];
    $user_name=$find[0]['username'];
    }
    $sql = "INSERT INTO note(title,content,date,user_account,admin_id,app_name,app_id,user_id,user_name)VALUES('{$_POST['title']}','{$_POST['content']}','{$_POST['date']}','{$_POST['user_account']}','{$admin['id']}','{$_POST['app_name']}','{$app_id}','{$user_id}','{$user_name}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>