<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO goods(title,content,money,number,admin_id,app_name,app_id)VALUES('{$_POST['title']}','{$_POST['content']}','{$_POST['money']}','{$_POST['number']}','{$admin['id']}','{$_POST['app_name']}','{$app_id}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>