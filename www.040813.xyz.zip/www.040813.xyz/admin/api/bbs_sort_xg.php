<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
$sql = "update bbs_sort set app_name='{$_POST['app_name']}',sort_name='{$_POST['sort_name']}',app_id='{$app_id}' where id = '{$_POST['id']}'";
$stmt = $pdo->prepare($sql);

if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>