<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
if(empty($_POST['password'])){
   $sql = "update admin set account='{$_POST['account']}',name='{$_POST['name']}',email='{$_POST['email']}' where id='{$_POST['id']}'"; 
}else{
   $psd = $_POST['password'];
   $sql = "update admin set account='{$_POST['account']}',password='{$psd}',name='{$_POST['name']}',email='{$_POST['email']}' where id = '{$_POST['id']}'";
   setcookie('admin','',time()-1,'/');
}
    $stmt = $pdo-> prepare($sql);
    if($stmt ->execute()){
        if(!empty($_POST['password'])){
           echo 2; 
        }else{
           echo 1;  
        }
    }else{
        echo 0;
    }

?>