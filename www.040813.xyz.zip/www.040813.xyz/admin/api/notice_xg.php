<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "update notice set app_name='{$_POST['app_name']}',title='{$_POST['title']}',content='{$_POST['content']}',date='{$_POST['date']}',remind_if='{$_POST['remind_if']}' where id = '{$_POST['id']}'";
    $stmt = $pdo->prepare($sql);
    if($stmt->execute()){
    	echo 1;
    }else{
    	echo 0;
    }
?>