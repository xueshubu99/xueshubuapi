<?php include '../public/config.php';
      include '../public/header_app.php';
?>
<?php
 $ids=$_POST['id'];
 $stmt = $pdo->prepare("DELETE FROM admin_notice WHERE id in($ids)"); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>