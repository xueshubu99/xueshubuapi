<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "select * from `admin_notice` ORDER BY id DESC";  
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo '{"code": 0,"msg": "","count":'.count($find).',"data":';
    echo json_encode($find);
    echo "}";
?>