<?php include '../public/config.php';
      include '../public/header.php';
?>
<?php
    $sql = "INSERT INTO notice(title,content,date,remind_if,admin_id,app_name,app_id)VALUES('{$_POST['title']}','{$_POST['content']}','{$_POST['date']}','{$_POST['remind_if']}','{$admin['id']}','{$_POST['app_name']}','{$app_id}')";
    $stmt = $pdo->prepare($sql); 
if($stmt->execute()){
	echo 1;
}else{
	echo 0;
}
?>