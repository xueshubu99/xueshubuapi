<?php include 'public/config.php'?>
<?php
     $_SESSION = array(); //清除SESSION值.

    if(isset($_COOKIE['admin'])){  //判断客户端的cookie文件是否存在,存在的话将其设置为过期.

    setcookie('admin','',time()-1,'/');
    echo 1;
    //   echo '<script>window.location.href="login.php";</script>';
    }
?>