<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>创梦IAPP后台管理系统</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
   <div class="layui-form-item">
        <label class="layui-form-label required">标签标题</label>
        <div class="layui-input-block">
            <input type="text" name="title" lay-verify="required" lay-reqtext="便签标题不能为空" placeholder="请输入便签标题" value="" class="layui-input title">
        </div>
    </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">便签内容</label>
                <div class="layui-input-block">
                    <textarea name="content" value="" placeholder="请输入便签内容" class="layui-textarea content"></textarea>
                </div>
            </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布时间</label>
        <div class="layui-input-block">
            <input type="text" name="date" placeholder="请输入发布时间" value="<?php echo $date;?>" class="layui-input date">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label">发布者昵称</label>
        <div class="layui-input-block">
            <input type="text" name="user_name" placeholder="请输入发布者昵称" value="<?php echo $admin['username'];?>" class="layui-input user_name">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布者账号</label>
        <div class="layui-input-block">
            <input type="text" name="user_account" placeholder="请输入发布者账号" value="<?php echo $admin['account'];?>" class="layui-input user_account">
        </div>
    </div>
            <div class="layui-form-item">
                <label class="layui-form-label  required">所属软件</label>
                <div class="layui-input-block">
                    <select name="app_name" lay-filter="" lay-verify="required" lay-reqtext="没有选择软件">
                        <?php 
                        $sql = "select * from app where admin_id='{$admin['id']}'";    
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute();
                        $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
                        if(empty($rows)){
                        ?>
                         <option value="">请先创建软件</option>   
                        <?php
                        }else{
                           foreach ($rows as $app){
                        ?>
                             <option value="<?php echo $app['app_name']?>"><?php echo $app['app_name'];?></option>
                      <?php 
                        }
                        }
                       ?>  
                    </select>
                </div>
            </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认添加</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/note_add.php',data.field,function(res){
          console.log(res)
                 if (res=='1') {
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
                        }
                        if(res=='0'){
                   layer.msg('添加失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }   
                             if(res=='2'){
                   layer.msg('用户与不属于该APP或用户不存在')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  } 
                      })
            return false;
        });

    });
</script>
</body>
</html>
 
 