<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <div class="layui-form-item">
        <label class="layui-form-label required">账号</label>
        <div class="layui-input-block">
            <input type="text" name="account" lay-verify="required" lay-reqtext="账号不能为空" placeholder="请输入账号" value="" class="layui-input account">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">密码</label>
        <div class="layui-input-block">
            <input type="text" name="password" lay-verify="required" lay-reqtext="密码不能为空" placeholder="请输入密码" value="" class="layui-input password">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">昵称</label>
        <div class="layui-input-block">
            <input type="text" name="username" placeholder="请输入昵称" value="张三" class="layui-input username">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label">金币</label>
        <div class="layui-input-block">
            <input type="number" name="money"  placeholder="请输入金币数量" value="0" class="layui-input money">
        </div>
    </div>
  <div class="layui-form-item">
        <label class="layui-form-label">经验</label>
        <div class="layui-input-block">
            <input type="number" name="experience" placeholder="请输入经验数量" value="0" class="layui-input experience">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">签名</label>
        <div class="layui-input-block">
            <input type="text" name="signature" placeholder="请输入签名" value="该用户很懒没有签名" class="layui-input signature">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">邮箱</label>
        <div class="layui-input-block">
            <input type="email" name="email" placeholder="请输入邮箱" value="" class="layui-input email">
        </div>
    </div>
  <div class="layui-form-item">
      <label class="layui-form-label">VIP状态</label>
    <div class="layui-input-block">
      <select name="vip_if" lay-filter="aihao">
            <option value="否">否</option>
             <option value="是">是(选择是请设置到期时间比开通时间长)</option>
    </select>
    </div>
</div>
                <div class="layui-form-item">
                <label class="layui-form-label  required">用户状态</label>
                <div class="layui-input-block">
                    <select name="state" lay-filter="" lay-verify="required" lay-reqtext="没有选择状态">
                         <option value="正常">正常</option>  
                         <option value="封禁">封禁</option> 
                    </select>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label  required">所属软件</label>
                <div class="layui-input-block">
                    <select name="app_name" lay-filter="" lay-verify="required" lay-reqtext="没有选择软件">
                        <?php 
                        $sql = "select * from app where admin_id='{$admin['id']}'";    
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute();
                        $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
                        if(empty($rows)){
                        ?>
                         <option value="">请先创建软件</option>   
                        <?php
                        }else{
                           foreach ($rows as $app){
                        ?>
                             <option value="<?php echo $app['app_name']?>"><?php echo $app['app_name'];?></option>
                      <?php 
                        }
                        }
                       ?>  
                    </select>
                </div>
            </div>
            
    <div class="layui-form-item">
        <label class="layui-form-label">注册日期</label>
        <div class="layui-input-block">
            <input type="text" name="date" placeholder="请输入注册日期" value="<?php echo $date;?>" class="layui-input date">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">VIP开通时间</label>
        <div class="layui-input-block">
            <input type="text" name="vip_start" placeholder="请输入VIP开通时间" value="<?php echo $date;?>" class="layui-input vip_start">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">VIP到期时间</label>
        <div class="layui-input-block">
            <input type="text" name="vip_end" placeholder="请输入VIP到期时间" value="<?php echo $date_1;?>" class="layui-input vip_end">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认添加</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/user_add.php',data.field,function(res){
                 if (res=='1') {
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
                        }else{
                           layer.msg('添加失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }   
                      })
            return false;
        });

    });
</script>
</body>
</html>
 
 