<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="adminid" value="<?php echo $admin['id'];?>" class="layui-input">
    <div class="layui-form-item">
        <label class="layui-form-label required">用户账号</label>
        <div class="layui-input-block">
            <input type="text" name="account" lay-verify="required" lay-reqtext="用户账号不能为空" placeholder="请输入用户账号" value="" class="layui-input">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label required">用户密码</label>
        <div class="layui-input-block">
            <input type="text" name="password" lay-verify="required" lay-reqtext="用户密码不能为空" placeholder="请输入用户密码" value="666admin" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">用户余额</label>
        <div class="layui-input-block">
            <input type="number" name="money" lay-verify="required" lay-reqtext="用户余额不能为空" placeholder="请输入用户余额" value="0" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">用户昵称</label>
        <div class="layui-input-block">
            <input type="text" name="username" lay-verify="required" lay-reqtext="用户昵称不能为空" placeholder="请输入用户昵称" value="创梦IAPP" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">用户邮箱</label>
        <div class="layui-input-block">
            <input type="email" name="email" lay-verify="required" lay-reqtext="用户邮箱不能为空" placeholder="请输入用户邮箱" value="1000@qq.com" class="layui-input">
        </div>
    </div>


    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认添加</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/admin_user_add.php',data.field,function(res){
          console.log(res)
                 if (res=='1') {
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
                        }
                  else{
                        layer.msg('添加失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }   
                      })
            return false;
        });

    });
</script>
</body>
</html>
 