<?php
/* *
 * 配置文件
 */
 
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

    include '../public/config.php';
    $sql = "select * from easypay where admin_id = '1'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	if(!empty($find)){
 	     	$easypay = $find[0];
 	}else {
 	    echo '支付信息未配置';
 	}
//商户ID
$alipay_config['partner']		= $easypay['pay_id'];

//商户KEY
$alipay_config['key']			= $easypay['pay_key'];


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


//签名方式 不需修改
$alipay_config['sign_type']    = strtoupper('MD5');

//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = 'https';

//支付API地址
$alipay_config['apiurl']    = $easypay['pay_website'];
?>