<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>学术部后端</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../css/public.css" media="all">
</head>
<body>
                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-bullhorn icon icon-tip"></i>系统公告</div>
                    <div class="layui-card-body layui-text">
<?php
include 'public/config.php';
    $sql = "select * from `admin_notice` where id = '{$_GET['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
if(!empty($find)){
        ?>
                <div class="layuimini-notice">
                <div class="layuimini-notice-title"> <?php echo $find[0]['content'];?> </a></div>
                </div>
<?php
}
?> 

                    </div>
                </div>
                </div>