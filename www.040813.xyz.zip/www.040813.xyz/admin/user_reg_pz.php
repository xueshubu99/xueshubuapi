<?php include 'public/config.php';
      include 'public/header.php';
      //查询用户注册配置信息
    $sql = "select * from user_reg_pz where admin_id='{$admin['id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $user_reg_pz =$find[0];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <div class="layui-form-item">
        <label class="layui-form-label required">注册赠送VIP天数</label>
        <div class="layui-input-block">
            <input type="number" name="reg_vip_time" lay-verify="required" lay-reqtext="注册赠送VIP天数不能为空" placeholder="请输入注册赠送VIP天数" value="<?php echo $user_reg_pz['reg_vip_time'];?>" class="layui-input reg_vip_time">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">注册赠送金币数量</label>
        <div class="layui-input-block">
            <input type="number" name="reg_money" lay-verify="required" lay-reqtext="注册赠送金币数量不能为空" placeholder="请输入注册赠送金币数量" value="<?php echo $user_reg_pz['reg_money'];?>" class="layui-input reg_money">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">注册赠送经验数量</label>
        <div class="layui-input-block">
            <input type="number" name="reg_experience" lay-verify="required" lay-reqtext="注册赠送经验数量不能为空" placeholder="请输入注册赠送经验数量" value="<?php echo $user_reg_pz['reg_experience'];?>" class="layui-input reg_experience">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认修改</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('api/user_reg_pz.php',data.field,function(res){
          console.log(res)
                 if (res=='1') {
                      layer.msg('修改成功')
        setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000)
                        }
                  else{
                        layer.msg('修改失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }   
                      })
            return false;
        });

    });
</script>
</body>
</html>
 