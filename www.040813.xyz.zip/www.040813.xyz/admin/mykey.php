<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>基本配置</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        .layui-form-item .layui-input-company {width: auto;padding-right: 10px;line-height: 38px;}
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">

        <div class="layui-form layuimini-form">
           <div class="layui-form-item">
                <label class="layui-form-label required">请输入mykey</label>
                <div class="layui-input-block">
<?php include 'public/config.php';
      include 'public/header.php';
$sql = "select * from mykey where admin_id = '{$admin['id']}'";
$stmt = $pdo->prepare($sql);
$stmt -> execute();
$find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
$mykey = $find[0];
?>                     <input type="hidden" name="id" value="<?php echo $mykey['id'];?>" class="id">
                    <input type="text" name="mykey" lay-verify="required" lay-reqtext="mykey不能为空" placeholder="请设置一个mykey"  value="<?php echo $mykey['mykey'];?>" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认保存</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="../../js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script>
    layui.use(['form','miniTab'], function () {
        var form = layui.form,
            layer = layui.layer,
            miniTab = layui.miniTab;
             $ = layui.$;
        //监听提交
        form.on('submit(saveBtn)', function (data) {
                  $.post('api/mykey_xg.php',data.field,function(res){
                      console.log(res)
                 if (res=='1') {
                     layer.msg('修改成功')
                        }else{
                     layer.msg('修改失败')
                        }
                      })
            
            return false;
        });

    });
</script>
</body>
</html>  