<?php
//判断用户登录状态
if (empty($_COOKIE['admin']) or empty($_COOKIE['cCode'])) {
?>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;
            layer.msg('你还未登录')
            setTimeout(function(){
     window.location.href="admin/login.php"
            },200)
    });
</script>
<?php
    }
    $date = date("Y-m-d H:i:s");
    $date_1 = date("Y-m-d H:i:s",strtotime( '-1 Minute'));
//查询网站配置信息
    $sql= "select * from website";
    $stmt=$pdo->prepare($sql);
    $stmt->execute();
    $find=$stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
    $website=$find[0];  
    }
   
//查询登陆者信息
    $sql = "select * from admin where id='{$_COOKIE['id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
    $admin =$find[0];
    }
  
//判断会员是否到期
    $sql = "SELECT * FROM user";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll();
    if(!empty($find)){
    foreach ($find as $users){
    if($users['vip_end']<$date){
    $sql = "UPDATE user SET vip_if='否' where id ='{$users['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }else{
    $sql = "UPDATE user SET vip_if='是' where id ='{$users['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
    }   
    }
    }
//查询注册赠送余额和添加软件的价格
      $sql = "select * from admin_pz where id = '1'";
      $stmt = $pdo->prepare($sql);
      $stmt ->execute();
      $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
      if(!empty($find)){
      $admin_pz = $find[0];    
      }
    
//定义超级管理员id
      $chaoji = '1';
//创建mykey
      $sql = "select * from mykey where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      $sql = "insert into mykey (mykey,admin_id)values('{$admin['id']}','{$admin['id']}')";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
//创建用户注册系统配置
      $sql = "select * from user_reg_pz where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      $sql = "insert into user_reg_pz (admin_id)values('{$admin['id']}')";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
//创建邮件配置
      $sql = "select * from mail where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      $sql = "insert into mail (username,password,smtp,port,admin_id)values('1648785@qq.com','password','smtp.qq.com','587','{$admin['id']}')";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
// 查询APPid
      if(!empty($_POST['app_name'])){
      $sql = "SELECT * FROM app where app_name='{$_POST['app_name']}' and admin_id='{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt->execute();
      $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      echo 5;
      exit;
      }else{
      $app_id = $find[0]['id'];
      }
      }
// 管理员app用户
      $sql = "select * from user where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(!empty($find)){
      foreach ($find as $row){
      $sql = "select * from app where app_name = '{$row['app_name']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
      $app_id2 = $find[0]['id'];
      $sql = "update user set app_id = '{$app_id2}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
      }
//数据库更新
    //   $sql = "select * from information_schema.TABLES where TABLE_NAME = 'user'";
    //   $stmt=$pdo->prepare($sql);
    //   $stmt->execute();
    //   $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //   if(empty($find)){
    //       echo '数据表不存在';
    //     //  这里不执行任何语句
    //   }else{
    //       echo '数据表已经存在';
    //     //   在这里执行创建数据表的语句
    //   }
    //   $sql = "select count(*) as count from information_schema.columns where table_name = 'user' and column_name = 'username3'";
    //   $stmt=$pdo->prepare($sql);
    //   $stmt->execute();
    //   $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //   if($find[0]['count']==0){
    //   $sql = "ALTER TABLE `user` ADD  `username3`  varchar(20) NULL DEFAULT '1' COMMENT '' AFTER `id`";
    //   $stmt=$pdo->prepare($sql);
    //   $stmt->execute();
    //   }
     
?>