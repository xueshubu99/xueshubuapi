<?php
//判断用户登录状态
if (empty($_COOKIE['admin']) or empty($_COOKIE['cCode'])) {
?>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;
            layer.msg('你还未登录')
            setTimeout(function(){
     window.location.href="admin/login.php"
            },200)
    });
</script>
<?php
    }
    $date = date("Y-m-d H:i:s");
    $date_1 = date("Y-m-d H:i:s",strtotime( '-1 Minute'));
//查询网站配置信息
    $sql= "select * from website";
    $stmt=$pdo->prepare($sql);
    $stmt->execute();
    $find=$stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
    $website=$find[0];  
    }
   
//查询登陆者信息
    $sql = "select * from admin where id='{$_COOKIE['id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
    $admin =$find[0];
    }
  
//判断会员是否到期
    $sql = "SELECT * FROM user";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll();
    if(!empty($find)){
    foreach ($find as $users){
    if($users['vip_end']<$date){
    $sql = "UPDATE user SET vip_if='否' where id ='{$users['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }else{
    $sql = "UPDATE user SET vip_if='是' where id ='{$users['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
    }   
    }
    }
//查询注册赠送余额和添加软件的价格
      $sql = "select * from admin_pz where id = '1'";
      $stmt = $pdo->prepare($sql);
      $stmt ->execute();
      $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
      if(!empty($find)){
      $admin_pz = $find[0];    
      }
    
//定义超级管理员id
      $chaoji = '1';
//创建mykey
      $sql = "select * from mykey where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      $sql = "insert into mykey (mykey,admin_id)values('{$admin['id']}','{$admin['id']}')";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
//创建用户注册系统配置
      $sql = "select * from user_reg_pz where admin_id = '{$admin['id']}'";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();
      $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
      if(empty($find)){
      $sql = "insert into user_reg_pz (admin_id)values('{$admin['id']}')";
      $stmt = $pdo->prepare($sql);
      $stmt -> execute();   
      }
      ?>