<?php include 'public/config.php';
      include 'public/header.php';

 	$sql = "select * from easypay where admin_id = '{$admin['id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	if(!empty($find)){
 	     	$yzf = $find[0];
 	}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>支付系统</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        .layui-form-item .layui-input-company {width: auto;padding-right: 10px;line-height: 38px;}
    </style>
</head>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">

        <div class="layui-form layuimini-form">
  <?php if(!empty($yzf)){
      ?>
                <div class="layui-form-item">
                <label class="layui-form-label">易支付域名</label>
                <div class="layui-input-block">
                    <input type="text" name="ym" placeholder=""  value="<?php echo $yzf['ym'];?>" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">商户ID</label>
                <div class="layui-input-block">
                    <input type="text" name="id" value="<?php echo $yzf['id'];?>" class="layui-input">
                </div>
            </div>
                        <div class="layui-form-item">
                <label class="layui-form-label">商户密钥</label>
                <div class="layui-input-block">
                    <input type="text" name="my"   value="<?php echo $yzf['my'];?>" class="layui-input">
                </div>
            </div>
      <?php
  }else{
    ?>
    
              <div class="layui-form-item">
                <label class="layui-form-label">易支付域名</label>
                <div class="layui-input-block">
                    <input type="text" name="ym" placeholder=""  value="" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">商户ID</label>
                <div class="layui-input-block">
                    <input type="text" name="id" value="" class="layui-input">
                </div>
            </div>
                        <div class="layui-form-item">
                <label class="layui-form-label">商户密钥</label>
                <div class="layui-input-block">
                    <input type="text" name="my"   value="" class="layui-input">
                </div>
            </div>
    
    
    <?php
    }
    ?>
           <div class="layui-form-item">
                <div class="layui-input-block">
                    <button type="submit" class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认保存</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script src="../../js/lay-config.js?v=1.0.4" charset="utf-8"></script>
<script>
    layui.use(['form','miniTab'], function () {
        var form = layui.form,
            layer = layui.layer,
            miniTab = layui.miniTab;
             $ = layui.$;
        //监听提交
        form.on('submit(saveBtn)', function (data) {
            // var index = layer.alert(JSON.stringify(data.field), {
            //     title: '最终的提交信息'
            // }, function () {
            //     layer.close(index);
            //     miniTab.deleteCurrentByIframe();
            // });
                  $.post('api/yzf.php',data.field,function(res){
                      console.log(res)
                 if (res=='1') {
                     layer.alert('修改成功')
                        }
                  if(res=='0')      
                        {
                            layer.alert('修改失败')
                        }
                      })
            
            return false;
        });

    });
</script>
</body>
</html>