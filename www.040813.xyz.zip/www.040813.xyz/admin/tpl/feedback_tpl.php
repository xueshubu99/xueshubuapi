<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="id" value="" class="id">
    <div class="layui-form-item">
        <label class="layui-form-label">反馈标题</label>
        <div class="layui-input-block">
            <input type="text" name="title" placeholder="" value="" class="layui-input title">
        </div>
    </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">反馈内容</label>
                <div class="layui-input-block">
                    <textarea name="content" value="" placeholder="" class="layui-textarea content"></textarea>
                </div>
            </div>
                <div class="layui-form-item">
        <label class="layui-form-label">反馈人邮箱</label>
        <div class="layui-input-block">
            <input type="text" name="email" placeholder="" value="" class="layui-input email">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">反馈时间</label>
        <div class="layui-input-block">
            <input type="text" name="date" placeholder="" value="" class="layui-input date">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">所属软件</label>
        <div class="layui-input-block">
            <input type="text" name="app_name" placeholder="" value="" class="layui-input app_name">
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
</body>
</html>
 