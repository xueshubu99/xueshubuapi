<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>创梦IAPP后台管理系统</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="id" value="" class="id">
    <div class="layui-form-item">
        <label class="layui-form-label required">标签标题</label>
        <div class="layui-input-block">
            <input type="text" name="title" lay-verify="required" lay-reqtext="便签标题不能为空" placeholder="请输入便签标题" value="" class="layui-input title">
        </div>
    </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">便签内容</label>
                <div class="layui-input-block">
                    <textarea name="content" value="" placeholder="请输入便签内容" class="layui-textarea content"></textarea>
                </div>
            </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布时间</label>
        <div class="layui-input-block">
            <input type="text" name="date" placeholder="请输入发布时间" value="" class="layui-input date">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label">发布者ID</label>
        <div class="layui-input-block">
            <input type="text" name="user_id" placeholder="请输入发布者账号" value="" class="layui-input user_id">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label">发布者昵称</label>
        <div class="layui-input-block">
            <input type="text" name="user_name" placeholder="请输入发布者账号" value="" class="layui-input user_name">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布者账号</label>
        <div class="layui-input-block">
            <input type="text" name="user_account" placeholder="请输入发布者账号" value="" class="layui-input user_account">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label  required">所属软件</label>
        <div class="layui-input-block">
            <input type="text" name="app_name" lay-verify="required" lay-reqtext="所属软件不能为空"  placeholder="请输入已经创建的软件" value="" class="layui-input app_name">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认修改</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/bq_xg.php',data.field,function(res){
                 if (res=='1') {
                      layer.msg('修改成功')
        setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000)
                        }
                  if(res=='0'){
                        layer.msg('修改失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }
                 if(res=='5'){
                        layer.msg('此软件名不存在或者不属于你')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  } 
                  
                      })
            return false;
        });

    });
</script>
</body>
</html>
 