<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="id" class= "id">
    <div class="layui-form-item">
        <label class="layui-form-label required">账号</label>
        <div class="layui-input-block">
            <input type="text" name="account" lay-verify="required" lay-reqtext="账号不能为空" placeholder="请输入账号" value="" class="layui-input account">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label required">密码</label>
        <div class="layui-input-block">
            <input type="text" name="password" lay-verify="required" lay-reqtext="密码不能为空" placeholder="请输入密码" value="" class="layui-input password">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">昵称</label>
        <div class="layui-input-block">
            <input type="text" name="username" placeholder="请输入昵称" value="" class="layui-input username">
        </div>
    </div>
        <div class="layui-form-item">
        <label class="layui-form-label">金币</label>
        <div class="layui-input-block">
            <input type="number" name="money"  placeholder="请输入金币数量" value="" class="layui-input money">
        </div>
    </div>
  <div class="layui-form-item">
        <label class="layui-form-label">经验</label>
        <div class="layui-input-block">
            <input type="number" name="experience" placeholder="请输入经验数量" value="" class="layui-input experience">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">签名</label>
        <div class="layui-input-block">
            <input type="text" name="signature" placeholder="请输入签名" value="" class="layui-input signature">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">邮箱</label>
        <div class="layui-input-block">
            <input type="email" name="email" placeholder="请输入邮箱" value="" class="layui-input email">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">VIP状态</label>
        <div class="layui-input-block">
            <input type="text" name="vip_if" placeholder="只能填是或者否" value="" class="layui-input vip_if">
        </div>
    </div>
                <div class="layui-form-item">
                <label class="layui-form-label  required">用户状态</label>
                <div class="layui-input-block">
                    <select name="state" lay-filter="" lay-verify="required" lay-reqtext="没有选择状态">
                         <option value="正常">正常</option>  
                         <option value="封禁">封禁</option> 
                    </select>
                </div>
            </div>
    <div class="layui-form-item">
        <label class="layui-form-label">所属软件</label>
        <div class="layui-input-block">
            <input type="text" name="app_name" placeholder="请输入已经创建的APP" value="" class="layui-input app_name">
        </div>
    </div>
            
    <div class="layui-form-item">
        <label class="layui-form-label">注册日期</label>
        <div class="layui-input-block">
            <input type="text" name="date_reg" placeholder="请输入注册日期" value="" class="layui-input date_reg">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">VIP开通时间</label>
        <div class="layui-input-block">
            <input type="text" name="vip_start" placeholder="请输入VIP开通时间" value="" class="layui-input vip_start">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">VIP到期时间</label>
        <div class="layui-input-block">
            <input type="text" name="vip_end" placeholder="请输入VIP到期时间" value="" class="layui-input vip_end">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认修改</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/user_xg.php',data.field,function(res){
                 if (res=='1') {
                      layer.msg('修改成功')
        setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000)
                        }
                  if(res=='0'){
                        layer.msg('修改失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }
                    if(res=='5'){
                        layer.msg('此软件名不存在或者不属于你')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  } 
                      })
            return false;
        });

    });
</script>
</body>
</html>
 