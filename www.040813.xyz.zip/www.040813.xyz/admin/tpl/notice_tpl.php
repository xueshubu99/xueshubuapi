<?php include '../public/config.php';
      include '../public/header.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>layui</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="../../lib/layui-v2.6.3/css/layui.css" media="all">
    <link rel="stylesheet" href="../../css/public.css" media="all">
    <style>
        body {
            background-color: #ffffff;
        }
    </style>
</head>
<body>
<div class="layui-form layuimini-form">
    <input type="hidden" name="id" value="" class="id">
    <div class="layui-form-item">
        <label class="layui-form-label required">公告标题</label>
        <div class="layui-input-block">
            <input type="text" name="title" lay-verify="required" lay-reqtext="公告标题不能为空" placeholder="请输入公告标题" value="" class="layui-input title">
        </div>
    </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">公告内容</label>
                <div class="layui-input-block">
                    <textarea name="content" value="" placeholder="请输入内容" class="layui-textarea content"></textarea>
                </div>
            </div>
    <div class="layui-form-item">
        <label class="layui-form-label">公告时间</label>
        <div class="layui-input-block">
            <input type="text" name="date" placeholder="请输入公告时间" value="" class="layui-input date">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">是否开启</label>
        <div class="layui-input-block">
            <input type="text" name="remind_if" placeholder="请输入是或者否" value="" class="layui-input remind_if">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label  required">所属软件</label>
        <div class="layui-input-block">
            <input type="text" name="app_name" lay-verify="required" lay-reqtext="所属软件不能为空"  placeholder="请输入已经创建的软件名" value="" class="layui-input app_name">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" lay-submit lay-filter="saveBtn">确认修改</button>
        </div>
    </div>
</div>
<script src="../../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;

        //监听提交
        form.on('submit(saveBtn)', function (data) {
       
      $.post('../api/notice_xg.php',data.field,function(res){
                 if (res=='1') {
                      layer.msg('修改成功')
        setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000)
                        }
                  if(res=='0'){
                        layer.msg('修改失败')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  }   
                  if(res=='5'){
                        layer.msg('此软件名不存在或者不属于你')
            setTimeout(function(){
                  var iframeIndex = parent.layer.getFrameIndex(window.name);
                    parent.layer.close(iframeIndex); 
            },1000) 
                  } 
                      })
            return false;
        });

    });
</script>
</body>
</html>