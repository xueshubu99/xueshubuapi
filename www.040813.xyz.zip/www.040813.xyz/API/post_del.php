<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['post_id'])){
   include 'header.php';
//开始
    $sql = "delete from bbs_pot where id = '{$_POST['post_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
   if($stmt -> execute()){
       echo json_encode(array("code" => 1, "msg" => "删除成功"), JSON_UNESCAPED_UNICODE);
       exit;
    }
    }else{
           echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
           exit;
    }    