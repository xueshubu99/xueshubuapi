<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['user_id']) and isset($_POST['app_id']) and isset($_POST['number'])){
   include 'header.php';
//判断账号是否正确
    $sql = "select * from user where id = '{$_POST['user_id']}' and app_id = '{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
        echo json_encode(array("code" => 2 , "msg" => "账号不存在"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
    $money = $find[0]['money'];
    $sql = "update user set money = '{$_POST['number']}' +'{$money}' where id = '{$_POST['user_id']}'";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "修改成功"), JSON_UNESCAPED_UNICODE);
        exit;   
    }else{
        echo json_encode(array("code" => 0 , "msg" => "修改失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
}
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
} 