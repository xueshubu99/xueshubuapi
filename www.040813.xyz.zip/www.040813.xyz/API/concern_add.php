<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['friend_id'])){
    include 'header.php';
//查询用户账号
    $sql = "select * from user where admin_id = '{$admin_id}' and app_id = '{$app_id}' and  id = '{$_POST['user_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "用户不存在"), JSON_UNESCAPED_UNICODE);
    exit;    
    }else{
    $username = $find[0]['username'];
    $user_id=$find[0]['id'];
    }
//查询对方账号
    $sql = "select * from user where admin_id = '{$admin_id}' and app_id = '{$app_id}' and  id = '{$_POST['friend_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "对方不存在"), JSON_UNESCAPED_UNICODE);
    exit;    
    }else{
    $friendname = $find[0]['username']; 
    $friend_id = $find[0]['id'];
    }    
//插入
    $sql = "insert into concern (user_id,user_name,friend_id,friend_name,date,app_id,app_name,admin_id)values('{$user_id}','{$username}','{$friend_id}','{$friendname}','{$date}','{$app_id}','{$app_name}','{$admin_id}');insert into chat (user_id,user_name,friend_id,friend_name,content,date,app_id,app_name,admin_id)values('{$friend_id}','{$friendname}','{$user_id}','{$username}','感谢关注！','{$date}','{$app_id}','{$app_name}','{$admin_id}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
    echo json_encode(array("code" => 1 , "msg" => "关注成功"), JSON_UNESCAPED_UNICODE);
    exit;
    }else{
    echo json_encode(array("code" => 0 , "msg" => "关注失败"), JSON_UNESCAPED_UNICODE);
    exit;
    }
    }else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
    }    