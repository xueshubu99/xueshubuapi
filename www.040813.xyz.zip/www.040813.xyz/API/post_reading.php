<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['number'])){
    include 'header.php';
    $sql = "select * from bbs_post where admin_id = '{$admin_id}' and app_id = '{$app_id}' and id='{$_POST['post_id']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	$number_reading = $find[0]['number_reading'];
    
//插入
    $sql = "update bbs_post set number_reading = ('{$number_reading}'+'{$_POST['number']}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "增加成功"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        echo json_encode(array("code" => 0 , "msg" => "增加失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    