<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['title']) and isset($_POST['content']) and isset($_POST['sort_id'])){
    include 'header.php';
//查询板块
    $sql = "select * from bbs_sort where id = '{$_POST['sort_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $sort = $find[0]['sort_name'];
//查询用户账号
    $sql = "select * from user where id = '{$_POST['user_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $user_id = $find[0]['id'];
    $account = $find[0]['account'];
    $username = $find[0]['username'];
//插入
    $img = "";
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443)?"https://": "http://";
    $url = "";
    echo count($_FILES['file']);
    var_dump($_FILES);
    if(is_array($_FILES['file']['tmp_name'])){
    $b =count($_FILES['file']['tmp_name'])-1;
    for($i=0;$i<count($_FILES['file']['tmp_name']);$i++){
    copy($_FILES['file']['tmp_name'][$i],"./img/".$_FILES['file']['name'][$i]);
    $url = $protocol . $_SERVER['HTTP_HOST'];
    if($i!=$b){
    $img = $img.$url."/API/img/".$_FILES['file']['name'][$i]."|";
    }
    else{
    $img = $img.$url."/API/img/".$_FILES['file']['name'][$i];
    }
    }
    }
    else{
    copy($_FILES['file']['tmp_name'],"./img/".$_FILES['file']['name']);
    $url = $protocol . $_SERVER['HTTP_HOST'];
    $img = $img.$url."/API/img/".$_FILES['file']['name'];
    }
    $sql = "insert into bbs_post (title,content,img,sort,state,user_id,user_account,user_name,date_publish,date_update,number_reading,number_good,app_id,app_name,admin_id)values('{$_POST['title']}','{$_POST['content']}','{$img}','{$sort}','待审核','{$user_id}','{$account}','{$username}','{$date}','{$date}','0','0','{$app_id}','{$app_name}','{$admin_id}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "添加成功"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        echo json_encode(array("code" => 0 , "msg" => "添加失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
    }else{
        echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
        exit;
    }    