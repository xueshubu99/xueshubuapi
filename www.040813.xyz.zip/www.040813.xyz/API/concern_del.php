<?php
    if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['friend_id'])){
    include 'header.php';
    $sql = "delete from concern where app_id='{$app_id}' and user_id = '{$_POST['user_id']}' and friend_id = '{$_POST['friend_id']}'";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
    echo json_encode(array("code" => 1 , "msg" => "删除成功"), JSON_UNESCAPED_UNICODE);
    exit;
    }else{
    echo json_encode(array("code" => 0 , "msg" => "删除失败"), JSON_UNESCAPED_UNICODE);
    exit;
    }
    }else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
    }    