<?php
 include '../admin/config.php';
//判断GET 
if (isset($_GET['note_id'])) {
    if(empty($_GET['note_id'])){
       echo json_encode(array("code" => 2 , "msg" => "便签ID不能为空"), JSON_UNESCAPED_UNICODE);
       exit;
       }

    $sql = "select * from note where id = '{$_GET['note_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
    
//判断便签是否存在    
   if(empty($rows)){
  	echo json_encode(array("code" => 0 , "msg" => "便签不存在"), JSON_UNESCAPED_UNICODE);  
  	exit;
    }
    
//成功执行
    echo $rows[0]['content'];        
    }
    
    //没有get值
    else {
        echo json_encode(array("code" => 3 , "msg" => "没有get值或get值不全"), JSON_UNESCAPED_UNICODE);
        } 
    ?>