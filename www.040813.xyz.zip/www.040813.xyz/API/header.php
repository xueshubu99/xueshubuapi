<?php
//  指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
// 响应头设置
header('Access-Control-Allow-Credentials:false');
header("Content-Type:text/html;charset=utf-8");
//设置时间函数
    $date = date("Y-m-d H:i:s");
    $date1 = date("Y-m-d H:i:s",strtotime("-1 minute"));
    include '../admin/public/config.php';
//判断用户ID是否存在
    $sql = "select * from admin where id = '{$_POST['id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
         echo json_encode(array("code" => 100 , "msg" => "用户ID不存在"), JSON_UNESCAPED_UNICODE);
         exit;
    }else{
        $admin_id = $find[0]['id'];
    }
//判断mykey是否正确
    $sql = "select * from mykey where admin_id = '{$admin_id}' and mykey='{$_POST['mykey']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
        echo json_encode(array("code" => 200 , "msg" => "mykey错误"), JSON_UNESCAPED_UNICODE);
        exit;
    }
//判断app是否存在
    $sql = "select * from app where id = '{$_POST['app_id']}' and admin_id = '{$admin_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
        echo json_encode(array("code" => 300 , "msg" => "软件不存在或者软件不属于你"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
    $app_id = $find[0]['id'];
    $app_name = $find[0]['app_name'];
    }
// 如果有user_id判断是否存在
    if(isset($_POST['user_id'])){
    $sql = "select * from `user` where id = '{$_POST['user_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);    
    if(empty($find)){
        echo json_encode(array("code" => 400 , "msg" => "用户不存在"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
    $user_id = $find[0]['id'];
    }
    }
//判断会员是否到期
    if(isset($_POST['account']) and !isset($_POST['password']) and !isset($_POST['username'])){
    $sql = "SELECT * FROM `user` where account = '{$_POST['account']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll();
    $user = $find[0];
    if($user['vip_end']<$date){
    $sql = "UPDATE `user` SET vip='否' where account ='{$user['account']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }else{
    $sql = "UPDATE `user` SET vip='是' where account ='{$user['account']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }   
    }
    ?>