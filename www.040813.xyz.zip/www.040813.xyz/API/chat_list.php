<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id_1']) and isset($_POST['user_id_2'])){
    include 'header.php';
//执行公告查询语句
 	$sql = "select * from chat where admin_id = '{$admin_id}' and app_id = '{$app_id}' and (user_id = '{$_POST['user_id_1']}' or user_id='{$_POST['user_id_2']}') and (friend_id = '{$_POST['user_id_1']}' or friend_id = '{$_POST['user_id_2']}' ORDER BY id DESC)";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	if(!empty($find)){
 	echo '{"code":"1","msg":"查询成功","data":';
    echo json_encode($find,JSON_UNESCAPED_UNICODE);
    echo '}';  
    exit;    
 	}else{
 	echo json_encode(array("code" => 0 , "msg" => "没有数据"), JSON_UNESCAPED_UNICODE);
    exit;
 	}
    }else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
    }