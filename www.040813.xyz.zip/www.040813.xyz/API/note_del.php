<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['note_id'])){
    include 'header.php';

    $sql = "delete from note where id = '{$_POST['note_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "删除成功"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        echo json_encode(array("code" => 0 , "msg" => "删除失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    