<?php
//  指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
// 响应头设置
header('Access-Control-Allow-Credentials:false');
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['title']) and isset($_POST['content']) and isset($_POST['email'])){
    include 'header.php';
//执行反馈语句
 	$sql = "INSERT INTO feedback(title,content,email,date,app_id,app_name,admin_id)VALUES('{$_POST['title']}','{$_POST['content']}','{$_POST['email']}','{$date}','{$app_id}','{$app_name}','{$admin_id}')";
 	$stmt = $pdo->prepare($sql);
 	if($stmt->execute()){
 	echo json_encode(array("code" => 1 , "msg" => "反馈成功"), JSON_UNESCAPED_UNICODE);
    exit;    
 	}else{
 	echo json_encode(array("code" => 0 , "msg" => "反馈失败"), JSON_UNESCAPED_UNICODE);
    exit;
 	}
}else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
}