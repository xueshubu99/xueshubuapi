
        <form name="alipayment" action="../admin/SDK/epayapi.php" method="post" target="_blank">
            <div id="body" style="clear:left">
                <dl class="content">
                        <input type="hidden" size="30" name="WIDout_trade_no" value="<?php echo date("YmdHis").mt_rand(100,999); ?>"/>
                        商品名称</br>
                        <input size="30" name="WIDsubject" value="1"/>
                        商品金额</br>
                        <input size="30" name="WIDtotal_fee" value="0.01"/>
                        <!--用户ID</br>-->
                        <!--<input size="30" name="adminid" value="100"/>-->
                    </dd>
					<dt>支付方式：</dt>
                    <dd>
                        <label><input type="radio" name="type" value="alipay" checked="">支付宝</label>&nbsp; <label><input type="radio" name="type" value="qqpay">QQ钱包</label>&nbsp;<label><input type="radio" name="type" value="wxpay">微信支付</label>&nbsp;<label><input type="radio" name="type" value="tenpay">财付通</label>
                    </dd>
                        <span class="new-btn-login-sp">
                            <button class="new-btn-login" type="submit" style="text-align:center;">确 认</button>
                        </span>
                    </dd>
                </dl>
            </div>
		</form>