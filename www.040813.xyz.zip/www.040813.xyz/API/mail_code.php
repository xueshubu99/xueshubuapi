<?php
   include '../admin/public/config.php';
 //判断用户ID是否存在
    $sql = "select * from admin where id = '{$_POST['id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
         echo json_encode(array("code" => 100 , "msg" => "用户ID不存在"), JSON_UNESCAPED_UNICODE);
         exit;
    }else{
        $admin_id = $find[0]['id'];
    }
    session_start();
 	$sql = "select * from mail where admin_id = '{$admin_id}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	if(!empty($find)){
 	$mail_pz = $find[0];
 	}
    $code = "";
   for ($i = 0; $i < 6; $i++) {
   $code .= rand(0, 9);
    }

  //4位验证码也可以用rand(1000,9999)直接生成

  //将生成的验证码写入session，备验证时用

setcookie('code',$code,time()+360000,'/');
echo json_encode(["code"=>$code,"msg"=>"发送成功"],JSON_UNESCAPED_UNICODE);

use PHPMailer\PHPMailer\PHPMailer; // 设置命名空间

use PHPMailer\PHPMailer\SMTP; // 设置命名空间

use PHPMailer\PHPMailer\Exception; // 设置命名空间

require '../mail/src/Exception.php';

require '../mail/src/PHPMailer.php';

require '../mail/src/SMTP.php';

$mail = new PHPMailer(true); // 创建邮件发送对象

try {

// 服务器相关设置

// $mail->SMTPDebug = SMTP::DEBUG_SERVER; // 输出服务器日志

$mail->isSMTP(); // 使用 SMTP 来发送邮件

$mail->SMTPAuth = true; // 启用 SMTP 身份验证

$mail->Host = $mail_pz['smtp']; // SMTP 服务器地址

$mail->Username = $mail_pz['username']; // SMTP 用户名
$mail->Password = $mail_pz['password']; // 密码

$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // 使用 TLS 加密

$mail->Port = $mail_pz['port']; // SMTP 端口

// 发件人和收件人

$mail->setFrom($mail_pz['username'], $mail_pz['username']); // 发件人

$mail->addAddress($_POST['tosend'], '收件人'); // 添加收件人

// 邮件标题和内容

$mail->isHTML(true); // 邮件格式设置为 HTML

$mail->Subject = '你的验证码是'; // 邮件标题

$mail->Body = $code; // HTML 内容

// $mail->AltBody = '文本'; // 纯文本

// $mail->addAttachment('tutorial.txt'); // 添加附件

$mail->send(); // 发送

} catch (Exception $e) {

// 输出错误信息

echo '错误:' . $mail->ErrorInfo;

}