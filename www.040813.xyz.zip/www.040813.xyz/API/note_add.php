<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['title']) and isset($_POST['content'])){
    include 'header.php';
//查询用户账号
    $sql = "select * from user where admin_id = '{$admin_id}' and app_id = '{$app_id}' and  id = '{$_POST['user_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "用户不存在"), JSON_UNESCAPED_UNICODE);
    exit;    
    }else{
    $account = $find[0]['account'];    
    }
//插入
    $sql = "insert into note (title,content,user_account,user_id,user_name,date_publish,date_update,app_id,app_name,admin_id)values('{$_POST['title']}','{$_POST['content']}','{$account}','{$find[0]['id']}','{$find[0]['username']}','{$date}','{$date}','{$app_id}','{$app_name}','{$admin_id}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "添加成功"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        echo json_encode(array("code" => 0 , "msg" => "添加失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    