<?php
//  指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
// 响应头设置
header('Access-Control-Allow-Credentials:false');
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id'])){
   include 'header.php';
//判断账号是否正确
    $sql = "select * from user where id = '{$_POST['user_id']}' and app_id = '{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
        echo json_encode(array("code" => 2 , "msg" => "账号不存在"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
    echo '{"code":"1","msg":"查询成功","data":';
    echo json_encode($find[0],JSON_UNESCAPED_UNICODE);
    echo '}';  
        exit;  
    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    