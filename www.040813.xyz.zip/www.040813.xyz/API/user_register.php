<?php
//  指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
// 响应头设置
header('Access-Control-Allow-Credentials:false');
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['account']) and isset($_POST['password']) and isset($_POST['username']) and isset($_POST['email'])){
   include 'header.php';
//查询账号是否重复
    $sql = "select * from user where admin_id = '{$admin_id}' and account = '{$_POST['account']}' and app_id = '{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
        echo json_encode(array("code" => 2 , "msg" => "账号已经存在"), JSON_UNESCAPED_UNICODE);
        exit; 
    } 
//查询邮箱是否重复
 /*   $sql = "select * from user where admin_id = '{$admin_id}' and email = '{$_POST['email']}' and app_id = '{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($find)){
        echo json_encode(array("code" => 2 , "msg" => "邮箱已经存在"), JSON_UNESCAPED_UNICODE);
        exit; 
    } */    
//查询用户注册配置
    $sql = "select * from user_reg_pz where admin_id = '{$admin_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
    $user_reg_pz = $find[0];
//执行注册语句
    $vip_end_cuo = strtotime("+".$user_reg_pz['reg_vip_time']. "day");
    $vip_end_ymd = date("Y-m-d H:i:s",$vip_end_cuo);
    $sql = "insert into user (account,password,username,email,money,experience,signature,vip_if,vip_start,vip_end,date_reg,date_last,admin_id,app_id,app_name)values('{$_POST['account']}','{$_POST['password']}','{$_POST['username']}','{$_POST['email']}','{$user_reg_pz['reg_money']}','{$user_reg_pz['reg_experience']}','这个人很懒什么也没写','是','{$date}','{$date1}','{$vip_end_ymd}','{$date1}','{$admin_id}','{$app_id}','{$app_name}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
    $find = $stmt -> fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(array("code" => 1 , "msg" => "注册成功"), JSON_UNESCAPED_UNICODE);
    //判断会员是否到期
    if(isset($_POST['account'])){
    $sql = "SELECT * FROM user where account = '{$_POST['account']}'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $find= $stmt->fetchAll();
    $user = $find[0];
    if($user['vip_end']<$date){
    $sql = "UPDATE user SET vip_if='否' where account ='{$user['account']}' and app_id = '{$app_id}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }else{
    $sql = "UPDATE user SET vip_if='是' where account ='{$user['account']}' and app_id = '{$app_id}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute(); 
     }   
    }
    exit; 
    }else{
    echo json_encode(array("code" => 0 , "msg" => "注册失败"), JSON_UNESCAPED_UNICODE);
    exit;    
    }
}
else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
}
?>