<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['content']) and isset($_POST['post_id'])){
   include 'header.php';
//查询帖子
    $sql = "select * from bbs_post where id = '{$_POST['post_id']}' and app_id='{$app_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "帖子不存在"), JSON_UNESCAPED_UNICODE);
    exit;    
    }
//查询用户账号
    $sql = "select * from user where id = '{$_POST['user_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 3 , "msg" => "用户不存在"), JSON_UNESCAPED_UNICODE);
    exit;    
    }
    $account = $find[0]['account'];
    $username = $find[0]['username'];
//插入
    $sql = "insert into bbs_comment (content,user_account,date,app_id,app_name,admin_id,post_id,user_name)values('{$_POST['content']}','{$account}','{$date}','{$app_id}','{$app_name}','{$admin_id}','{$_POST['post_id']}','{$username}')";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
    echo json_encode(array("code" => 1 , "msg" => "添加成功"), JSON_UNESCAPED_UNICODE);
    exit;
    }else{
    echo json_encode(array("code" => 0 , "msg" => "添加失败"), JSON_UNESCAPED_UNICODE);
    exit;
    }
    }else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
    }    