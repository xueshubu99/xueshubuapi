<?php
    if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['content'])){
    include 'header.php';
    //执行卡密查询语句
    $_POST['content'] = trim($_POST['content']);
 	$sql = "select * from carmine where admin_id = '{$admin_id}' and app_id = '{$app_id}' and content = '{$_POST['content']}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();
 	$find = $stmt->fetchAll(PDO::FETCH_ASSOC);
 	if(!empty($find)){
 	$carmine = $find[0];
 	if($carmine['state']=="未使用"){
 	echo json_encode(array("code" => 1 , "msg" => "使用成功"), JSON_UNESCAPED_UNICODE);
 	$sql = "update carmine set state='已使用' where content = '{$_POST['content']}' and app_id = '{$app_id}' and admin_id = '{$admin_id}'";
 	$stmt = $pdo->prepare($sql);
 	$stmt->execute();   
 	exit;
 	}else{
 	echo json_encode(array("code" => 2 , "msg" => "卡密已经被使用"), JSON_UNESCAPED_UNICODE);
 	exit;
 	}
 	}else{
 	echo json_encode(array("code" => 0 , "msg" => "卡密不存在"), JSON_UNESCAPED_UNICODE);
    exit;
 	}
    }else{
        echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
        exit;
    }