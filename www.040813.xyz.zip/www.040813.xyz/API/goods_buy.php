<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['goods_id'])  and isset($_POST['user_id'])){
   include 'header.php';
//判断商品是否存在
    $sql = "select * from goods where id = '{$_POST['goods_id']}' and app_id = '{$app_id}' and admin_id = '{$admin_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
        echo json_encode(array("code" => 2 , "msg" => "商品不存在"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        // 查询用户余额
    $goods = $find[0];
    $sql = "select * from user where id = '{$_POST['user_id']}' and app_id = '{$app_id}' and admin_id = '{$admin_id}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
          echo json_encode(array("code" => 4 , "msg" => "用户不存在"), JSON_UNESCAPED_UNICODE);
        exit;   
    }
    $user = $find[0];
    if($user['money']<$goods['money']){
    echo json_encode(array("code" => 3 , "msg" => "余额不足"), JSON_UNESCAPED_UNICODE);
    exit; 
    }else{
    $sql = "update user set money =('{$user['money']}'-'{$goods['money']}') where id = '{$_POST['user_id']}' and app_id = '{$app_id}' and admin_id = '{$admin_id}'";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
    echo json_encode(array("code" => 1 , "msg" => "购买成功"), JSON_UNESCAPED_UNICODE);
    $sql = "INSERT INTO goods_order (goods_name,user_account,pay_money,date,app_id,app_name,admin_id)VALUES('{$goods['title']}','{$user['account']}','{$goods['money']}','{$date}','{$app_id}','{$app_name}','{$admin_id}')";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    exit;   
    }else{
    echo json_encode(array("code" => 0 , "msg" => "购买失败"), JSON_UNESCAPED_UNICODE);
    exit;
    }
    }

    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    