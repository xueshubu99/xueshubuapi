<?php
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['note_id']) and isset($_POST['title']) and isset($_POST['content'])){
    include 'header.php';
//查询便签
    $sql = "select * from note where admin_id = '{$admin_id}' and app_id = '{$app_id}' and  id = '{$_POST['note_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "便签ID错误"), JSON_UNESCAPED_UNICODE);
    exit;    
    }
//修改
    $sql = "update note set title='{$_POST['title']}',content='{$_POST['content']}',date_update='{$date}' where id = '{$_POST['note_id']}'";
    $stmt = $pdo->prepare($sql);
    if($stmt -> execute()){
        echo json_encode(array("code" => 1 , "msg" => "修改成功"), JSON_UNESCAPED_UNICODE);
        exit;
    }else{
        echo json_encode(array("code" => 0 , "msg" => "修改失败"), JSON_UNESCAPED_UNICODE);
        exit;
    }
}else{
       echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
       exit;
}    