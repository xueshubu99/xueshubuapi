<?php
//  指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET, POST, OPTIONS');
// 响应头设置
header('Access-Control-Allow-Credentials:false');
if(isset($_POST['id']) and isset($_POST['mykey']) and isset($_POST['app_id']) and isset($_POST['user_id']) and isset($_POST['vip_day'])){
   include 'header.php';
//判断账号是否正确
    $sql = "select * from user where admin_id = '{$admin_id}' and app_id = '{$app_id}' and id = '{$_POST['user_id']}'";
    $stmt = $pdo->prepare($sql);
    $stmt -> execute();
    $find = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($find)){
    echo json_encode(array("code" => 2 , "msg" => "账号不存在"), JSON_UNESCAPED_UNICODE);
    exit;
    }else{
    $user = $find[0];
    // 用户剩余vip时间的时间戳
    $vip_end = strtotime($user['vip_end']);
    // 现在的时间戳
    $datenow = strtotime("now");
    // 现在的Ymd时间
    $datenow1 = date("Y-m-d H:i:s");
	if($vip_end>$datenow){
	 //加上后的到期时间 时间戳 
	$date = strtotime("+".$_POST['vip_day']."day",$vip_end);
    //加上后的到期时间Ymd
	$date1 = date("Y-m-d H:i:s",$date);
	$sql = "UPDATE user SET vip_if='是',vip_end='{$date1}' WHERE id='{$_POST['user_id']}';";
 	$stmt = $pdo->prepare($sql);
 	if($stmt->execute()){
 	echo json_encode(array("code" => 1 , "msg" => "修改成功"), JSON_UNESCAPED_UNICODE);
    exit;    
 	}else{
 	echo json_encode(array("code" => 0 , "msg" => "修改失败"), JSON_UNESCAPED_UNICODE);
    exit;    
 	}
	}else{
	 //加上后的到期时间 时间戳 
	$date = strtotime("+".$_POST['vip_day']."day",$datenow);
// 	加上后的到期时间
	$date2 = date("Y-m-d H:i:s",$date);
	$sql = "UPDATE user SET vip_if='是',vip_end='{$date2}',vip_start='{$datenow1}' WHERE id='{$_POST['user_id']}';";
 	$stmt = $pdo->prepare($sql);
 	if($stmt->execute()){
 	echo json_encode(array("code" => 1 , "msg" => "修改成功"), JSON_UNESCAPED_UNICODE);
    exit;    
 	}else{
 	echo json_encode(array("code" => 0 , "msg" => "修改失败"), JSON_UNESCAPED_UNICODE);
    exit;    
 	}
	}
    }
}else{
    echo json_encode(array("code" => 500 , "msg" => "没有POST参数或者参数不全"), JSON_UNESCAPED_UNICODE);
    exit;
}    