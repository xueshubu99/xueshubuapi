<?php

use PHPMailer\PHPMailer\PHPMailer; // 设置命名空间

use PHPMailer\PHPMailer\SMTP; // 设置命名空间

use PHPMailer\PHPMailer\Exception; // 设置命名空间

require 'src/Exception.php';

require 'src/PHPMailer.php';

require 'src/SMTP.php';

$mail = new PHPMailer(true); // 创建邮件发送对象

try {

// 服务器相关设置

// $mail->SMTPDebug = SMTP::DEBUG_SERVER; // 输出服务器日志

$mail->isSMTP(); // 使用 SMTP 来发送邮件

$mail->SMTPAuth = true; // 启用 SMTP 身份验证

$mail->Host = 'smtp.qq.com'; // SMTP 服务器地址

$mail->Username = '1648785@qq.com'; // SMTP 用户名
$mail->Password = 'kvkdtimcqxpqeced'; // 密码

$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // 使用 TLS 加密

$mail->Port = '587'; // SMTP 端口

// 发件人和收件人

$mail->setFrom('1648785@qq.com', '创梦流浪人'); // 发件人

$mail->addAddress('647551725@qq.com', '阿碧'); // 添加收件人

// 邮件标题和内容

$mail->isHTML(true); // 邮件格式设置为 HTML

$mail->Subject = '这是邮件标题'; // 邮件标题

$mail->Body = '这是 HTML 内容 加粗的文字'; // HTML 内容

$mail->AltBody = '文本内容'; // 纯文本

// $mail->addAttachment('tutorial.txt'); // 添加附件

$mail->send(); // 发送

echo '发送完成';
} catch (Exception $e) {

// 输出错误信息

echo '错误:' . $mail->ErrorInfo;

}