<?php
    $file = 'a.txt';
    if(file_exists($file)){
?>
<script src="../lib/layui-v2.6.3/layui.js" charset="utf-8"></script>
<script>
     layui.use(['form','layer'], function () {
        var form = layui.form,
            layer = layui.layer,
            $ = layui.$;
            layer.msg('已经安装过了')
            setTimeout(function(){
     window.location.href="../admin/index.php"
            },1000)
    });
</script>

<?php
    }

if(!empty($_POST)){
$date = date('Y-m-d H:i:s');

// 连接数据库
$host = $_POST['sql_host'];//一般不用修改
$sjkusername = $_POST['sql_account'];//数据库账号
$sjkpassword = $_POST['sql_password'];//数据库密码
$dbname = $_POST['sql_name'];//数据库名称
try {
$pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", "$sjkusername" , "$sjkpassword" , array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8';"));
	if ($pdo) {
// 保存数据库配置    
$sql_host = file_get_contents('../admin/public/config.php');
$sql_host = str_replace('sql_host',$_POST['sql_host'],$sql_host);
file_put_contents('../admin/public/config.php',$sql_host);

$sql_account = file_get_contents('../admin/public/config.php');
$sql_account = str_replace('sql_account',$_POST['sql_account'],$sql_account);
file_put_contents('../admin/public/config.php',$sql_account);

$sql_password = file_get_contents('../admin/public/config.php');
$sql_password = str_replace('sql_password',$_POST['sql_password'],$sql_password);
file_put_contents('../admin/public/config.php',$sql_password);

$sql_name = file_get_contents('../admin/public/config.php');
$sql_name = str_replace('sql_name',$_POST['sql_name'],$sql_name);
file_put_contents('../admin/public/config.php',$sql_name);

// 创建数据表
$sql = "DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `money` float(200,0) NOT NULL DEFAULT '0',
  `date_reg` varchar(255) NOT NULL,
  `date_last` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `admin_notice`;
CREATE TABLE `admin_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `friend_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `friend_name` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `concern`;
CREATE TABLE `concern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `friend_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `friend_name` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `port` varchar(255) NOT NULL,
  `smtp` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `admin_pz`;
CREATE TABLE `admin_pz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_pay` float(255,0) NOT NULL DEFAULT '0',
  `money_reg` float(255,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `app`;
CREATE TABLE `app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `bbs_comment`;
CREATE TABLE `bbs_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` varchar(255) NOT NULL,
  `post_id` int(255) NOT NULL,
  `user_account` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `bbs_post`;
CREATE TABLE `bbs_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `sort` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL DEFAULT '待审核',
  `user_id` int(11) NOT NULL,
  `user_account` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `date_publish` varchar(255) NOT NULL,
  `date_update` varchar(255) NOT NULL,
  `number_reading` varchar(255) NOT NULL,
  `number_good` int(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `bbs_sort`;
CREATE TABLE `bbs_sort` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_name` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `carmine`;
CREATE TABLE `carmine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `easypay`;
CREATE TABLE `easypay` (
  `id` int(11) NOT NULL,
  `pay_website` varchar(255) NOT NULL,
  `pay_id` int(11) NOT NULL,
  `pay_key` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(500) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(500) NOT NULL,
  `money` float(255,0) NOT NULL,
  `number` int(11) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `goods_order`;
CREATE TABLE `goods_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(255) NOT NULL,
  `user_account` varchar(255) NOT NULL,
  `pay_money` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `mykey`;
CREATE TABLE `mykey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mykey` varchar(255) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
INSERT INTO `mykey` VALUES ('1', '', '0');

DROP TABLE IF EXISTS `note`;
CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_account` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `date` varchar(255) NOT NULL,
  `remind_if` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `update`;
CREATE TABLE `update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `version` varchar(255) NOT NULL DEFAULT '1.0',
  `download_url` varchar(500) NOT NULL,
  `update_if` varchar(255) NOT NULL,
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(255) NOT NULL DEFAULT NULL DEFAULT 'https://www.bcdog.cn/wp-content/uploads/2022/06/mmexport1651509384455-150x150.jpg',
  `account` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `money` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `date_reg` varchar(255) DEFAULT NULL,
  `date_last` varchar(255) DEFAULT NULL,
  `vip_if` varchar(1) DEFAULT NULL,
  `vip_start` varchar(255) DEFAULT NULL,
  `vip_end` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL DEFAULT '1',
  `app_id` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `admin_id` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `user_reg_pz`;
CREATE TABLE `user_reg_pz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reg_money` varchar(255) NOT NULL DEFAULT '0',
  `reg_experience` varchar(255) NOT NULL DEFAULT '0',
  `reg_vip_time` varchar(255) NOT NULL DEFAULT '0',
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `website`;
CREATE TABLE `website` (
  `id` int(11) NOT NULL,
  `web_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `wangbei` varchar(255) DEFAULT NULL,
  `icp` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `website` VALUES ('1', '创梦IAPP后台管理系统', '一个简单好上手的IAPP后台管理系统', 'iapp,iapp后台,创梦iapp,创梦iapp后台管理系统', '', '');

INSERT INTO `admin` VALUES ('1', '{$_POST['admin_account']}', '{$_POST['admin_password']}', '{$_POST['admin_username']}', '{$_POST['admin_email']}', '99999','{$date}','{$date}');

INSERT INTO `admin_pz` VALUES ('1', '0', '0');

INSERT INTO `user_reg_pz` VALUES ('1', '0', '0','1');

INSERT INTO `mail`(username,password,port,smtp,admin_id) VALUES ('1648785@qq.com', '123456789', '587','smtp.qq.com','1');
";
$stmt = $pdo->prepare($sql);
if($stmt->execute()){
    $file=fopen("a.txt","w");
    echo '安装完成';
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443)?"https://": "http://";
    $url = $protocol . $_SERVER['HTTP_HOST'];
    header("Location: $url"); 
}
	}
} catch (PDOException $e) {
	echo $e->getMessage();
}
}
?>
<!DOCTYPE html>
<html>

<head>

<title>创梦IAPP后台管理系统程序安装</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">
<style>
    div{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
</head>

<body>
    <div>
<form method="post" action="index.php">
    主机名(默认localhost):</br>
    <input type="text" name="sql_host" value="localhost">
    </br>数据库账号:</br>
    <input type="text" name="sql_account" value="">
    </br>数据库密码:</br>
    <input type="text" name="sql_password" value="">
    </br>数据库名称:</br>
    <input type="text" name="sql_name" value="">
    </br>管理员账号:</br>
    <input type="text" name="admin_account" value="">
    </br>管理员密码:</br>
    <input type="text" name="admin_password" value="">
    </br>管理员昵称:</br>
    <input type="text" name="admin_username" value="">
    </br>管理员邮箱:</br>
    <input type="text" name="admin_email" value="">
    </br></br>
    <button>立 即 安 装</button>
</form>
</div>
</body>

</html>